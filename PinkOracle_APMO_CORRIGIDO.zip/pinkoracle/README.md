# Pink Oracle

Aplicativo React Native/Expo de jogo de adivinhação numérica.

## Como executar

1. Abra a pasta do projeto no terminal.
2. Instale as dependências:

```bash
npm install
```

3. Inicie o Expo:

```bash
npx expo start
```

Se o Metro estiver usando um cache antigo, execute:

```bash
npx expo start -c
```

## Observação

O projeto não depende mais do carregamento da fonte personalizada para renderizar a tela inicial. A lógica dos limites do jogo também foi convertida para estado do React, evitando valores globais entre partidas.
