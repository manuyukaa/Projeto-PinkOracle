import React, { useEffect, useState } from 'react';
import { SafeAreaView, StatusBar, StyleSheet, Text, View } from 'react-native';
import AsyncStorage from '@react-native-async-storage/async-storage';
import StartGameScreen from './screens/StartGameScreen';
import GameScreen from './screens/GameScreen';
import GameOverScreen from './screens/GameOverScreen';
import { COLORS } from './constants/Colors';

const RECORD_KEY = 'pink-oracle-record';

export default function App() {
  const [screen, setScreen] = useState('start');
  const [secretNumber, setSecretNumber] = useState(null);
  const [difficulty, setDifficulty] = useState({ id: 'normal', label: 'Clássico', min: 1, max: 99 });
  const [history, setHistory] = useState([]);
  const [record, setRecord] = useState(null);

  useEffect(() => {
    let mounted = true;

    AsyncStorage.getItem(RECORD_KEY)
      .then(value => {
        if (mounted && value !== null) setRecord(Number(value));
      })
      .catch(() => {});

    return () => {
      mounted = false;
    };
  }, []);

  const startGame = (number, mode) => {
    setSecretNumber(number);
    setDifficulty(mode);
    setHistory([]);
    setScreen('game');
  };

  const finishGame = async rounds => {
    if (record === null || rounds < record) {
      setRecord(rounds);
      try {
        await AsyncStorage.setItem(RECORD_KEY, String(rounds));
      } catch (_) {}
    }
    setScreen('over');
  };

  const newGame = () => {
    setSecretNumber(null);
    setHistory([]);
    setScreen('start');
  };

  return (
    <SafeAreaView style={styles.root}>
      <StatusBar barStyle="dark-content" backgroundColor={COLORS.background} />
      {screen === 'start' && <StartGameScreen onStartGame={startGame} record={record} />}
      {screen === 'game' && (
        <GameScreen
          secretNumber={secretNumber}
          difficulty={difficulty}
          history={history}
          setHistory={setHistory}
          onGameOver={finishGame}
        />
      )}
      {screen === 'over' && (
        <GameOverScreen
          secretNumber={secretNumber}
          difficulty={difficulty}
          history={history}
          record={record}
          onNewGame={newGame}
        />
      )}
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  root: {
    flex: 1,
    backgroundColor: COLORS.background,
  },
});
