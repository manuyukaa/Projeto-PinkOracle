export const COLORS = {
  background: '#FFF9FB',
  blush: '#FCE4EC',
  palePink: '#FFF0F5',
  pink: '#F5B8CA',
  rose: '#D95D85',
  deepRose: '#B83E68',
  text: '#4A3440',
  textSoft: '#866F79',
  muted: '#B39BA4',
  white: '#FFFFFF',
  gold: '#E7A94B',
  ripple: '#F3A9BF'
};
