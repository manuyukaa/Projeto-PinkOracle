import React, { useEffect, useState } from 'react';
import { Alert, FlatList, ImageBackground, StyleSheet, Text, View } from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import * as Haptics from 'expo-haptics';
import { Ionicons } from '@expo/vector-icons';
import PrimaryButton from '../components/game/PrimaryButton';
import GuessLogItem from '../components/game/GuessLogItem';
import Card from '../components/ui/Card';
import Title from '../components/ui/Title';
import { COLORS } from '../constants/Colors';

function generateGuess(min, maxExclusive, exclude) {
  if (maxExclusive <= min) return min;

  const available = maxExclusive - min;
  if (available <= 1) return min;

  let guess = Math.floor(Math.random() * available) + min;
  while (guess === exclude) {
    guess = Math.floor(Math.random() * available) + min;
  }
  return guess;
}

export default function GameScreen({ secretNumber, difficulty, history, setHistory, onGameOver }) {
  const [currentGuess, setCurrentGuess] = useState(null);
  const [minLimit, setMinLimit] = useState(difficulty.min);
  const [maxLimit, setMaxLimit] = useState(difficulty.max);
  const [finished, setFinished] = useState(false);

  useEffect(() => {
    const min = difficulty.min;
    const max = difficulty.max;
    setMinLimit(min);
    setMaxLimit(max);
    setFinished(false);
    setCurrentGuess(generateGuess(min, max + 1, secretNumber));
  }, [difficulty, secretNumber]);

  useEffect(() => {
    if (currentGuess === secretNumber && !finished) {
      setFinished(true);
      Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success).catch(() => {});
      onGameOver(history.length + 1);
    }
  }, [currentGuess, secretNumber, history.length, finished, onGameOver]);

  const nextGuess = direction => {
    if (currentGuess === null || finished) return;

    if (direction === 'lower' && currentGuess < secretNumber) {
      Alert.alert('O oráculo não mente!', 'Essa dica contradiz o número secreto. Escolha outra direção.');
      return;
    }

    if (direction === 'higher' && currentGuess > secretNumber) {
      Alert.alert('O oráculo não mente!', 'Essa dica contradiz o número secreto. Escolha outra direção.');
      return;
    }

    const nextHistory = [{ value: currentGuess, direction }, ...history];
    setHistory(nextHistory);

    let nextMin = minLimit;
    let nextMax = maxLimit;

    if (direction === 'lower') nextMax = currentGuess - 1;
    if (direction === 'higher') nextMin = currentGuess + 1;

    setMinLimit(nextMin);
    setMaxLimit(nextMax);

    const next = generateGuess(nextMin, nextMax + 1, secretNumber);
    setCurrentGuess(next);
  };

  if (currentGuess === null) return null;

  const round = history.length + 1;

  return (
    <LinearGradient colors={[COLORS.blush, COLORS.background, '#FFFFFF']} style={styles.root}>
      <ImageBackground
        source={require('../assets/pink-pattern.png')}
        resizeMode="cover"
        imageStyle={styles.pattern}
        style={styles.background}
      >
        <View style={styles.content}>
          <View style={styles.header}>
            <View style={styles.headerText}>
              <Text style={styles.eyebrow}>PINK ORACLE • {difficulty.label.toUpperCase()}</Text>
              <Title style={styles.smallTitle}>Lendo sua mente ✦</Title>
            </View>
            <View style={styles.roundBadge}>
              <Text style={styles.roundNumber}>{round}</Text>
              <Text style={styles.roundLabel}>palpite</Text>
            </View>
          </View>

          <Card style={styles.guessCard}>
            <Text style={styles.question}>Minha leitura é...</Text>
            <View style={styles.numberCircle}>
              <Text style={styles.guess}>{currentGuess}</Text>
            </View>
            <Text style={styles.prompt}>Esse número é maior ou menor?</Text>

            <View style={styles.buttons}>
              <PrimaryButton
                title="Menor"
                icon="chevron-down"
                onPress={() => nextGuess('lower')}
                style={styles.button}
              />
              <PrimaryButton
                title="Maior"
                icon="chevron-up"
                onPress={() => nextGuess('higher')}
                style={styles.button}
              />
            </View>
          </Card>

          <View style={styles.status}>
            <Ionicons name="sparkles-outline" size={18} color={COLORS.rose} />
            <Text style={styles.statusText}>Intervalo atual: {minLimit} — {maxLimit}</Text>
          </View>

          <Text style={styles.historyTitle}>Últimos palpites</Text>
          <FlatList
            data={history}
            renderItem={({ item, index }) => <GuessLogItem item={item} index={index} />}
            keyExtractor={(item, index) => `${item.value}-${index}`}
            contentContainerStyle={styles.listContent}
            ListEmptyComponent={<Text style={styles.empty}>O histórico aparece conforme você dá as dicas.</Text>}
          />
        </View>
      </ImageBackground>
    </LinearGradient>
  );
}

const styles = StyleSheet.create({
  root: { flex: 1 },
  background: { flex: 1 },
  pattern: { opacity: 0.12 },
  content: { flex: 1, padding: 20 },
  header: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', marginBottom: 18 },
  headerText: { flex: 1 },
  eyebrow: { color: COLORS.rose, fontSize: 11, fontWeight: '800', letterSpacing: 1 },
  smallTitle: { fontSize: 25, marginTop: 2 },
  roundBadge: { backgroundColor: COLORS.white, borderRadius: 18, paddingHorizontal: 14, paddingVertical: 8, alignItems: 'center', elevation: 2 },
  roundNumber: { color: COLORS.rose, fontWeight: '800', fontSize: 18 },
  roundLabel: { color: COLORS.muted, fontSize: 9 },
  guessCard: { alignItems: 'center', padding: 22 },
  question: { color: COLORS.textSoft, fontSize: 14, marginBottom: 12 },
  numberCircle: { width: 142, height: 142, borderRadius: 71, backgroundColor: COLORS.palePink, borderWidth: 3, borderColor: COLORS.pink, alignItems: 'center', justifyContent: 'center', marginBottom: 14 },
  guess: { color: COLORS.rose, fontSize: 48, fontWeight: '800' },
  prompt: { color: COLORS.text, fontSize: 15, fontWeight: '700', marginBottom: 16 },
  buttons: { flexDirection: 'row', width: '100%' },
  button: { flex: 1, marginHorizontal: 5 },
  status: { flexDirection: 'row', alignItems: 'center', justifyContent: 'center', marginVertical: 14 },
  statusText: { color: COLORS.textSoft, fontSize: 12, marginLeft: 7 },
  historyTitle: { fontSize: 15, fontWeight: '800', color: COLORS.text, marginBottom: 8 },
  listContent: { paddingBottom: 20 },
  empty: { color: COLORS.muted, fontSize: 12, textAlign: 'center', padding: 12 },
});
