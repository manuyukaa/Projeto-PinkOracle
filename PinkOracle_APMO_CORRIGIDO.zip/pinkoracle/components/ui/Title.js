import React from 'react';
import { StyleSheet, Text } from 'react-native';
import { COLORS } from '../../constants/Colors';

export default function Title({ children, style }) {
  return <Text style={[styles.title, style]}>{children}</Text>;
}

const styles = StyleSheet.create({
  title: {
    fontSize: 34,
    fontWeight: '800',
    color: COLORS.deepRose,
    textAlign: 'center',
    marginTop: 10,
    marginBottom: 6,
    letterSpacing: 0.3,
  },
});
